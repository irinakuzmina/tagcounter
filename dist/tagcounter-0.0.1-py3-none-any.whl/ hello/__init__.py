# hello.py
def hello(name):
  print(f"Привет, {name}!")

if __name__ == '__main__':
  hello('Dimex')
